# Storyboard · Montei o time. E agora? — pontos, preço e Judocoins (v1)

| # | Tempo | Quadro | Enquadramento / câmara | Texto | Som | Saída |
|---|---|---|---|---|---|---|
| c01 | 00:0000–00:0006 | Grelha de 8 favoritos; contador de JC a cair. | plano geral da grelha / fixa; micro-zoom no contador aos 4 s | ONLY FAVORITES? / IT CAN COST YOU JUDOCOINS. | entrada: pulso grave + pluck tenso, intensidade baixa; whoosh de cartas; 'tick' descendente no contador | corte seco |
| c02 | 00:0006–00:0012 | Dôdo 3D pensativo que aponta. | plano médio / push-in lento | NOW WHAT? | tema entra (batida hip-hop leve ~95 BPM), média-baixa; 'plim' no gesto | congela 1 s e divide o ecrã ao meio |
| c03 | 00:0012–00:0020 | Dois placares lado a lado. | plano fixo / fixa | POINTS → RANKING / JUDOCOINS → NEXT TEAM | tema, média; 'tic' em cada coluna | a coluna JUDOCOINS expande |
| c04 | 00:0020–00:0029 | Carta com linha-meta e barra de pontos. | close na carta / fixa | THE PRICE IS THE TARGET / POINTS > PRICE = ▲ RISES / POINTS < PRICE = ▼ DROPS | tema, média; enchimento ascendente; 'buzz' curto no vermelho | a carta vira para o exemplo |
| c05 | 00:0029–00:0040 | Favorito 18 JC → 8 pts → 13 JC, dono −5 JC. | close na carta, depois plano do contador / push-in no −5 | THE FAVORITE DROPPED / AND YOU PAID / 18 → 13 JC / YOU: −5 JC | tema desce (tensão), média; 'pop' por ação; queda grave no −5 | deslize lateral |
| c06 | 00:0040–00:0048 | Aposta 6 JC → 16 pts → 11 JC, dono +2,5 JC. | close na carta / fixa | BARGAIN · 6 JC / SCORED 16 / 6 → 11 JC / YOU: +2.5 JC | tema sobe, média-alta; caixa registadora suave | as duas cartas lado a lado |
| c07 | 00:0048–00:0056 | Balança assimétrica. | plano fixo / fixa | RISES? YOU KEEP HALF. / DROPS? YOU TAKE IT ALL. | corte de música 0,3 s em 'Percebeu?' e volta; 'clonk' da balança | corte |
| c08 | 00:0056–01:0005 | Favorito que cumpre a meta. | close / fixa | FAVORITES RISE TOO / 18 → 21 JC / IF THEY SCORE MORE THAN THEY COST | tema, média-alta; enchimento ascendente | a carta ganha a moldura dourada de capitão |
| c09 | 01:0005–01:0010 | Capitão dobra pontos, não JC. | close / punch-in | CAPTAIN: POINTS ×2 / JUDOCOINS ×1 | tema, alta; 'clack' da moldura | fundido |
| c10 | 01:0010–01:0020 | Dôdo 3D pensa e faz positivo; ecrã final. | plano médio → ecrã final / fixa, leve subida | DON'T JUST ASK WHO'LL WIN. / ASK WHO'LL SCORE MORE THAN THEY COST. / BUILD YOUR TEAM · LINK IN BIO | resolve no acorde final; 'ding' no botão | fim |
