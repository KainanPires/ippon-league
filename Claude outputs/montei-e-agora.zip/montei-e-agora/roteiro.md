# Roteiro · Montei o time. E agora? — pontos, preço e Judocoins (versão 1)

> Documento de planeamento. **Não autoriza nenhum gasto.**

| Campo | Valor |
|---|---|
| Objetivo | Fazer quem já montou equipa perceber que o preço é uma meta de pontos e que desvalorizar custa Judocoins para a próxima rodada |
| Público | jogadores que montaram o time com os favoritos sem conhecer a valorização |
| Promessa | Você joga dois placares: pontos e Judocoins |
| Hipótese | Mostrar um favorito que faz o dono perder JC gera mais partilhas e comentários do que explicar só a regra |
| Formato / redes | Instagram Reels, TikTok, YouTube Shorts |
| Duração total | 80 s |
| Idioma | EN (inglês) |
| CTA | Build your team — link in bio |
| Link UTM | https://www.ipponleague.com/?utm_source=instagram&utm_medium=❓&utm_campaign=montei-e-agora&utm_content=favorito-custa-v1 |

## Cenas

### c01 · 00:0000–00:0006 (6 s) · gancho
- **Origem:** motion (estúdio de cenas)
- **Cenário:** fundo da marca (#0c0e0d, textura diagonal, partículas douradas); grelha de 8 cartas de atletas fictícios, todas com selo dourado 'FAVORITO'
- **Personagens:** 8 cartas com nomes inventados (ex.: K. MORITA · JPN · −73 kg; A. VOLKOV · GEO · −90 kg; L. SANTOS · BRA · −57 kg; M. DUBOIS · FRA · −70 kg …)
- **Ação:** as 8 cartas entram em cascata; o selo FAVORITO brilha; em baixo um contador 'SEUS JUDOCOINS' desce de 100 para 91 a vermelho
- **Enquadramento:** plano geral da grelha
- **Câmara:** fixa; micro-zoom no contador aos 4 s
- **Texto em ecrã:** "ONLY FAVORITES?" (Oswald creme, topo) · "IT CAN COST YOU JUDOCOINS." (Oswald dourado; 'COST' vermelho)
- **Narração:** Built your team with only favorites? [pausa 0,3 s] Careful: that can cost you Judocoins.
- **Música:** entrada: pulso grave + pluck tenso, intensidade baixa
- **Efeitos sonoros:** whoosh de cartas, 'tick' descendente no contador
- **Transição de saída:** corte seco

### c02 · 00:0006–00:0012 (6 s) · viragem — Dôdo
- **Origem:** higgsfield (G1)
- **Cenário:** estúdio escuro, chão de tatame verde-escuro, luz de recorte dourada
- **Personagens:** Dôdo 3D
- **Ação:** Dôdo cruza os braços, pensa, e aponta para a câmara com confiança
- **Enquadramento:** plano médio
- **Câmara:** push-in lento
- **Texto em ecrã:** "NOW WHAT?" (Oswald dourado, topo)
- **Narração:** Team's ready… now what? [pausa 0,3 s] Here, you play two scoreboards.
- **Música:** tema entra (batida hip-hop leve ~95 BPM), média-baixa
- **Efeitos sonoros:** 'plim' no gesto
- **Transição de saída:** congela 1 s e divide o ecrã ao meio
- **Geração:** `kling3_0` × 1
  - Parâmetros: `{"prompt":"He crosses his arms thinking, then uncrosses them and points confidently at the camera with a playful smile. Dark studio, dark green tatami floor, golden rim light, slow push-in. The cartoon platypus judoka mascot from the start image, vinyl-toy 3D look: teal rounded head, wide flat orange bill, orange eyebrows, white judogi, black belt, small teal tail. Keep the exact character design, proportions and colors. No text, no other characters.","aspect_ratio":"9:16","duration":5,"mode":"pro","sound":"off"}`
  - Referências: assets/dodo/3d/dodo3d_0.5.jpg

### c03 · 00:0012–00:0020 (8 s) · os dois placares
- **Origem:** motion (estúdio de cenas)
- **Cenário:** ecrã dividido: esquerda PONTOS (ícone de pódio, seta para 'RANKING'); direita JUDOCOINS (ícone de moeda JC, seta para 'TIME DA PRÓXIMA RODADA')
- **Personagens:** Dôdo 2D sábio ao centro, em baixo
- **Ação:** cada coluna acende quando é dita
- **Enquadramento:** plano fixo
- **Câmara:** fixa
- **Texto em ecrã:** "POINTS → RANKING" (Oswald creme + dourado) · "JUDOCOINS → NEXT TEAM" (Oswald creme + dourado)
- **Narração:** Points move you up the ranking. [pausa 0,2 s] Judocoins decide the team you can afford next round.
- **Música:** tema, média
- **Efeitos sonoros:** 'tic' em cada coluna
- **Transição de saída:** a coluna JUDOCOINS expande

### c04 · 00:0020–00:0029 (9 s) · a regra
- **Origem:** motion (estúdio de cenas)
- **Cenário:** carta de atleta estilo app: 'PREÇO 18 JC' com uma linha-meta dourada; barra de pontos a encher
- **Personagens:** Dôdo 2D indicando
- **Ação:** a barra enche até passar a linha (verde, seta ▲ 'VALORIZA'); volta atrás e fica abaixo (vermelho, ▼ 'DESVALORIZA')
- **Enquadramento:** close na carta
- **Câmara:** fixa
- **Texto em ecrã:** "THE PRICE IS THE TARGET" (Oswald dourado) · "POINTS > PRICE = ▲ RISES" (verde) · "POINTS < PRICE = ▼ DROPS" (vermelho)
- **Narração:** Every athlete's price is a points target. [pausa 0,2 s] Score more than he costs? He rises. Score less? He drops.
- **Música:** tema, média
- **Efeitos sonoros:** enchimento ascendente, 'buzz' curto no vermelho
- **Transição de saída:** a carta vira para o exemplo

### c05 · 00:0029–00:0040 (11 s) · exemplo — favorito
- **Origem:** motion (estúdio de cenas)
- **Cenário:** carta 'FAVORITO · 18 JC'; mini-placar das lutas: LUTA 1 IPPON +10 · LUTA 2 perdeu por waza-ari −2 → 8 PONTOS; preço 18 → 13 (▼ −5); em baixo 'SEU PATRIMÔNIO −5 JC'
- **Personagens:** favorito inventado: KENTA MORITA · JPN · −73 kg
- **Ação:** cartões de ação entram, total 8 abaixo da meta 18; preço cai a vermelho; contador de património −5
- **Enquadramento:** close na carta, depois plano do contador
- **Câmara:** push-in no −5
- **Texto em ecrã:** "THE FAVORITE DROPPED" (Oswald creme) · "AND YOU PAID" (Oswald vermelho) · "18 → 13 JC" (vermelho) · "YOU: −5 JC" (Oswald vermelho grande)
- **Narração:** Look at this favorite: he cost eighteen. [pausa 0,2 s] Won one fight by ippon, lost the next by waza-ari: eight points. [pausa 0,3 s] He dropped to thirteen… and you lost five Judocoins.
- **Música:** tema desce (tensão), média
- **Efeitos sonoros:** 'pop' por ação, queda grave no −5
- **Transição de saída:** deslize lateral

### c06 · 00:0040–00:0048 (8 s) · exemplo — aposta
- **Origem:** motion (estúdio de cenas)
- **Cenário:** carta 'APOSTA · 6 JC'; total 16 PONTOS acima da meta; preço 6 → 11 (▲ +5); 'SEU PATRIMÔNIO +2,5 JC'
- **Personagens:** aposta inventada: RAFAEL LIMA · BRA · −66 kg
- **Ação:** barra passa a meta; preço sobe a verde; contador +2,5
- **Enquadramento:** close na carta
- **Câmara:** fixa
- **Texto em ecrã:** "BARGAIN · 6 JC" (Oswald creme) · "SCORED 16" (Oswald verde) · "6 → 11 JC" (verde) · "YOU: +2.5 JC" (Oswald verde grande)
- **Narração:** Now a bargain at six who scored sixteen. [pausa 0,2 s] He rose to eleven, and you gained two and a half.
- **Música:** tema sobe, média-alta
- **Efeitos sonoros:** caixa registadora suave
- **Transição de saída:** as duas cartas lado a lado

### c07 · 00:0048–00:0056 (8 s) · a assimetria
- **Origem:** motion (estúdio de cenas)
- **Cenário:** balança: prato verde 'SUBIU +5 → VOCÊ +2,5' leve; prato vermelho 'CAIU −5 → VOCÊ −5' pesado
- **Personagens:** Dôdo 2D sábio
- **Ação:** a balança pende para o lado vermelho
- **Enquadramento:** plano fixo
- **Câmara:** fixa
- **Texto em ecrã:** "RISES? YOU KEEP HALF." (verde) · "DROPS? YOU TAKE IT ALL." (vermelho)
- **Narração:** See it? [pausa 0,3 s] When an athlete rises, you keep half. When he drops, you take the whole drop.
- **Música:** corte de música 0,3 s em 'Percebeu?' e volta
- **Efeitos sonoros:** 'clonk' da balança
- **Transição de saída:** corte

### c08 · 00:0056–01:0005 (9 s) · equilíbrio — o favorito também pode valorizar
- **Origem:** motion (estúdio de cenas)
- **Cenário:** carta 'FAVORITO · 18 JC' com 24 PONTOS acima da meta; preço 18 → 21 (▲ +3); 'VOCÊ +1,5 JC'
- **Personagens:** favorito inventado: IRAKLI BERIDZE · GEO · −90 kg
- **Ação:** barra passa a meta; preço sobe
- **Enquadramento:** close
- **Câmara:** fixa
- **Texto em ecrã:** "FAVORITES RISE TOO" (Oswald creme + dourado) · "18 → 21 JC" (verde) · "IF THEY SCORE MORE THAN THEY COST" (Manrope creme)
- **Narração:** Favorites rise too, if they score more than they cost: [pausa 0,2 s] an eighteen who scores twenty-four goes to twenty-one.
- **Música:** tema, média-alta
- **Efeitos sonoros:** enchimento ascendente
- **Transição de saída:** a carta ganha a moldura dourada de capitão

### c09 · 01:0005–01:0010 (5 s) · capitão
- **Origem:** motion (estúdio de cenas)
- **Cenário:** carta com moldura dourada de capitão: pontos ×2 (brilho), Judocoins ×1 (cinza, riscado o ×2)
- **Personagens:** carta
- **Ação:** ×2 acende nos pontos; nos JC aparece ×2 riscado
- **Enquadramento:** close
- **Câmara:** punch-in
- **Texto em ecrã:** "CAPTAIN: POINTS ×2" (dourado) · "JUDOCOINS ×1" (cinza)
- **Narração:** And your captain doubles the points… [pausa 0,3 s] not the Judocoins.
- **Música:** tema, alta
- **Efeitos sonoros:** 'clack' da moldura
- **Transição de saída:** fundido

### c10 · 01:0010–01:0020 (10 s) · CTA
- **Origem:** higgsfield (G2) + ecrã final
- **Cenário:** estúdio escuro com raios dourados; depois ecrã final com logótipo
- **Personagens:** Dôdo 3D
- **Ação:** Dôdo toca na têmpora (pensar) e faz sinal de positivo para a câmara; nos 5 s finais: logótipo + botão
- **Enquadramento:** plano médio → ecrã final
- **Câmara:** fixa, leve subida
- **Texto em ecrã:** "DON'T JUST ASK WHO'LL WIN." (Oswald creme) · "ASK WHO'LL SCORE MORE THAN THEY COST." (Oswald dourado) · "BUILD YOUR TEAM · LINK IN BIO" (botão dourado)
- **Narração:** So don't just ask who'll win. [pausa 0,2 s] Ask who'll score more than he costs. Build your team on Ippon League.
- **Música:** resolve no acorde final
- **Efeitos sonoros:** 'ding' no botão
- **Transição de saída:** fim
- **Geração:** `kling3_0` × 1
  - Parâmetros: `{"prompt":"He taps his temple with one finger as if thinking smart, then gives a confident thumbs up to the camera. Dark studio, golden light rays, floating golden particles, camera fixed with a slight rise. The cartoon platypus judoka mascot from the start image, vinyl-toy 3D look: teal rounded head, wide flat orange bill, orange eyebrows, white judogi, black belt, small teal tail. Keep the exact character design, proportions and colors. No text, no other characters.","aspect_ratio":"9:16","duration":5,"mode":"pro","sound":"off"}`
  - Referências: assets/dodo/3d/dodo3d_0.5.jpg

## Mapa musical

| De | Até | Faixa | Fonte / licença | Intensidade | Nota |
|---|---|---|---|---|---|
| 00:0000 | 00:0006 | Trilha instrumental da biblioteca do CapCut, filtro de uso comercial. Procurar: 'sport hip hop', 'hip hop beat', 'trap' ou 'energetic confident'. 90–100 BPM, sem voz, com batida marcada e um 'drop' claro. | CapCut (biblioteca) / ❓ | baixa | tensão |
| 00:0006 | 00:0038 | Trilha instrumental da biblioteca do CapCut, filtro de uso comercial. Procurar: 'sport hip hop', 'hip hop beat', 'trap' ou 'energetic confident'. 90–100 BPM, sem voz, com batida marcada e um 'drop' claro. | CapCut (biblioteca) / ❓ | média | desce na c05 (perda) |
| 00:0038 | 01:0010 | Trilha instrumental da biblioteca do CapCut, filtro de uso comercial. Procurar: 'sport hip hop', 'hip hop beat', 'trap' ou 'energetic confident'. 90–100 BPM, sem voz, com batida marcada e um 'drop' claro. | CapCut (biblioteca) / ❓ | média-alta | corte de 0,3 s em 'Percebeu?' (~46 s) |
| 01:0010 | 01:0020 | Trilha instrumental da biblioteca do CapCut, filtro de uso comercial. Procurar: 'sport hip hop', 'hip hop beat', 'trap' ou 'energetic confident'. 90–100 BPM, sem voz, com batida marcada e um 'drop' claro. | CapCut (biblioteca) / ❓ | resolução | acorde final no botão |

## Narração corrida

Built your team with only favorites? [pausa 0,3 s] Careful: that can cost you Judocoins. Team's ready… now what? [pausa 0,3 s] Here, you play two scoreboards. Points move you up the ranking. [pausa 0,2 s] Judocoins decide the team you can afford next round. Every athlete's price is a points target. [pausa 0,2 s] Score more than he costs? He rises. Score less? He drops. Look at this favorite: he cost eighteen. [pausa 0,2 s] Won one fight by ippon, lost the next by waza-ari: eight points. [pausa 0,3 s] He dropped to thirteen… and you lost five Judocoins. Now a bargain at six who scored sixteen. [pausa 0,2 s] He rose to eleven, and you gained two and a half. See it? [pausa 0,3 s] When an athlete rises, you keep half. When he drops, you take the whole drop. Favorites rise too, if they score more than they cost: [pausa 0,2 s] an eighteen who scores twenty-four goes to twenty-one. And your captain doubles the points… [pausa 0,3 s] not the Judocoins. So don't just ask who'll win. [pausa 0,2 s] Ask who'll score more than he costs. Build your team on Ippon League.

## Factos usados (verificar com ippon-produto)

- D = pontos − preço; novo preço = preço + 50% de D; piso 2 JC — fonte: lib/engine.ts computeNewPrice (IMPLEMENTADO · VERIFICADO)
- Património do dono: ganha metade da valorização, perde a desvalorização inteira — fonte: lib/congelar.ts (IMPLEMENTADO)
- Orçamento para montar = património atual + JC comprados — fonte: app/api/orcamento/route.ts (IMPLEMENTADO)
- Capitão dobra os pontos; a variação de património do capitão não é dobrada — fonte: lib/congelar.ts (IMPLEMENTADO)
- Exemplos: 18→8 pts→13 JC (dono −5); 6→16 pts→11 JC (+2,5); 18→24 pts→21 JC (+1,5); luta ippon +10 e waza-ari sofrido −2 = 8 — fonte: calculado com computeNewPrice e scoreContestSide (30/09/2026) (VERIFICADO)
