#!/usr/bin/env node
// conteudo/scripts/guarda-gasto.mjs
//
// TRAVA DE GASTO — hook PreToolUse do Claude Code.
// Corre antes de qualquer ferramenta cujo nome contenha "higgsfield".
// Sai com código 2 (= bloqueia a ferramenta) se a geração não estiver aprovada.
//
// Regras:
//  1. Ferramentas só de leitura (listar modelos, saldo, histórico…) passam sempre.
//  2. Tudo o resto é tratado como GERAÇÃO PAGA (fail-closed) e exige:
//     - conteudo/.campanha-ativa com o slug da campanha;
//     - conteudo/campanhas/<slug>/aprovacao.json com estado "aprovado", não expirado;
//     - roteiro.md com o MESMO sha256 que foi aprovado;
//     - chamadas aprovadas ainda por usar e créditos estimados dentro do máximo.
//  3. Cada chamada autorizada é registada em campanhas/<slug>/gastos.jsonl.

import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

const LEITURA = /(list|get_|_get|status|balance|saldo|credit|models?$|history|historico|search|describe|info|whoami|account)/i;
const GERACAO = /(generat|create|render|upscale|edit|animate|video|image|run|submit|train|lipsync|speech|voice|swap|extend)/i;

function bloquear(msg) {
  process.stderr.write(`⛔ TRAVA DE GASTO: ${msg}\nNenhuma geração foi feita. Ver conteudo/conhecimento/05-integracoes-e-gasto.md.\n`);
  process.exit(2);
}

let entrada = "";
for await (const c of process.stdin) entrada += c;
let evento;
try { evento = JSON.parse(entrada); } catch { bloquear("não consegui ler o pedido da ferramenta."); }

const ferramenta = String(evento.tool_name || "");
if (!/higgsfield/i.test(ferramenta)) process.exit(0);
const nomeCurto = ferramenta.split("__").pop();
if (LEITURA.test(nomeCurto) && !GERACAO.test(nomeCurto)) process.exit(0);

const raiz = process.env.CLAUDE_PROJECT_DIR || evento.cwd || process.cwd();
const base = path.join(raiz, "conteudo");
const ficheiroAtiva = path.join(base, ".campanha-ativa");
if (!fs.existsSync(ficheiroAtiva)) bloquear("não há campanha ativa (conteudo/.campanha-ativa).");
const slug = fs.readFileSync(ficheiroAtiva, "utf8").trim();
if (!/^[a-z0-9-_]+$/i.test(slug)) bloquear(`slug inválido em .campanha-ativa: "${slug}".`);

const pasta = path.join(base, "campanhas", slug);
const fAprov = path.join(pasta, "aprovacao.json");
const fRoteiro = path.join(pasta, "roteiro.md");
const fGastos = path.join(pasta, "gastos.jsonl");
if (!fs.existsSync(fAprov)) bloquear(`campanha "${slug}" sem aprovacao.json — o roteiro e o orçamento ainda não foram aprovados.`);
if (!fs.existsSync(fRoteiro)) bloquear(`campanha "${slug}" sem roteiro.md.`);

let aprov;
try { aprov = JSON.parse(fs.readFileSync(fAprov, "utf8")); } catch { bloquear("aprovacao.json ilegível."); }
if (aprov.estado !== "aprovado") bloquear(`estado da aprovação é "${aprov.estado}", não "aprovado".`);
if (!aprov.expira_em || Date.now() > Date.parse(aprov.expira_em)) bloquear("aprovação expirada ou sem data de validade.");

const hash = crypto.createHash("sha256").update(fs.readFileSync(fRoteiro)).digest("hex");
if (hash !== aprov.roteiro_sha256) bloquear("o roteiro.md mudou depois da aprovação. Precisa de nova aprovação.");

const usadas = fs.existsSync(fGastos)
  ? fs.readFileSync(fGastos, "utf8").split("\n").filter(Boolean).map((l) => JSON.parse(l))
  : [];
const lista = Array.isArray(aprov.chamadas_aprovadas) ? aprov.chamadas_aprovadas : [];
const proxima = lista[usadas.length];
if (!proxima) bloquear(`as ${lista.length} chamadas aprovadas já foram usadas.`);

const gastoEstimado = usadas.reduce((s, u) => s + (Number(u.creditos_estimados) || 0), 0);
const depois = gastoEstimado + (Number(proxima.creditos_estimados) || 0);
if (!(Number(aprov.creditos_maximos) > 0)) bloquear("creditos_maximos não definido na aprovação.");
if (depois > Number(aprov.creditos_maximos)) bloquear(`excederia o máximo aprovado (${depois} > ${aprov.creditos_maximos} créditos).`);

fs.appendFileSync(fGastos, JSON.stringify({
  quando: new Date().toISOString(),
  chamada: proxima.id,
  cena: proxima.cena,
  modelo_aprovado: proxima.modelo,
  ferramenta,
  creditos_estimados: proxima.creditos_estimados,
  acumulado_estimado: depois,
  entrada: evento.tool_input ?? null,
}) + "\n");
process.stderr.write(`✅ Chamada ${proxima.id} (cena ${proxima.cena}) autorizada · ${depois}/${aprov.creditos_maximos} créditos estimados.\n`);
process.exit(0);
