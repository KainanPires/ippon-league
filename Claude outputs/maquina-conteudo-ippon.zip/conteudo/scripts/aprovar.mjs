#!/usr/bin/env node
// conteudo/scripts/aprovar.mjs — corre-o TU no terminal (o Claude está proibido de o executar).
//
//   node conteudo/scripts/aprovar.mjs <slug> <creditos_maximos> <dias_de_validade>
//
// Lê campanhas/<slug>/orcamento.json (lista de chamadas gerada pelo orçamentista),
// mostra o resumo, pede confirmação e escreve aprovacao.json com o hash do roteiro.
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import readline from "node:readline/promises";

const [slug, maxStr, diasStr] = process.argv.slice(2);
if (!slug || !maxStr || !diasStr) { console.error("Uso: node conteudo/scripts/aprovar.mjs <slug> <creditos_maximos> <dias>"); process.exit(1); }
const pasta = path.join(process.cwd(), "conteudo", "campanhas", slug);
const roteiro = fs.readFileSync(path.join(pasta, "roteiro.md"));
const orc = JSON.parse(fs.readFileSync(path.join(pasta, "orcamento.json"), "utf8"));
const chamadas = orc.chamadas || [];
const total = chamadas.reduce((s, c) => s + (Number(c.creditos_estimados) || 0), 0);
console.log(`\nCampanha: ${slug}\nChamadas: ${chamadas.length}\nCréditos estimados: ${total}\nMáximo que vais autorizar: ${maxStr}\nValidade: ${diasStr} dias\n`);
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const r = await rl.question('Escreve "APROVO" para autorizar este gasto: ');
rl.close();
if (r.trim() !== "APROVO") { console.log("Não aprovado. Nada foi escrito."); process.exit(1); }
const agora = new Date();
fs.writeFileSync(path.join(pasta, "aprovacao.json"), JSON.stringify({
  slug, estado: "aprovado", aprovado_por: "Kainan",
  aprovado_em: agora.toISOString(),
  expira_em: new Date(agora.getTime() + Number(diasStr) * 864e5).toISOString(),
  roteiro_sha256: crypto.createHash("sha256").update(roteiro).digest("hex"),
  creditos_maximos: Number(maxStr),
  chamadas_aprovadas: chamadas,
}, null, 2));
fs.writeFileSync(path.join(process.cwd(), "conteudo", ".campanha-ativa"), slug);
console.log("Aprovado. aprovacao.json escrito e campanha ativada.");
