# Máquina de Conteúdo · Ippon League — estado, decisões e plano

Atualizado: 30/09/2026 · Nenhuma geração paga foi feita.

## 1. Fontes lidas
- Repositório `KainanPires/ippon-league` (branch `main`, commit `e816cac`, 29/09/2026) — **fonte da verdade do produto**.
- Pasta local `ippon-league/Claude outputs/`: `brief-projeto-marketing.md`, `plano-marketing-lancamento-ippon-league.md`, `kpis-ippon-league.md`, `plano-de-equipa-ippon-league.md`, `spec-economia-v2.md`, `plano-ippon-studio.md`, `sprint-analytics-fase-A.md` + cópias de código (os PDFs são versões dos mesmos .md).
- ⚠️ A pasta local `ippon-league` (fora de "Claude outputs") é um esqueleto antigo de junho, branch `master` — **não reflete a app atual**.

## 2. Mapa: existe · especificado · a implementar
| Item | Estado |
|---|---|
| App, motor de pontuação, mercado, faixas, ligas, Copa do Dôdo, planos | ✅ existe (código) |
| Dôdo (SVG com 5 expressões, faixa e judogi variáveis), paleta, fontes | ✅ existe |
| Eventos de funil no PostHog + construtor de UTM (`/admin/utm`) | ✅ existe |
| Papel `is_admin` na tabela `users` | ✅ existe (o plano do Studio dizia que não — já está desatualizado) |
| Ippon Studio (simulador de cenas para gravar) | 📄 especificado, **não implementado** |
| Brief de marketing, ângulos, KPIs, convenção UTM | 📄 especificado |
| Pacote de referência do Dôdo (70 PNG + SVG) | ✅ criado hoje, sem custo |
| Base de conhecimento 01–07 (este Projeto) | ✅ criada hoje |
| Esqueleto `conteudo/` + subagentes + trava de gasto | ✅ preparado hoje, **por instalar no repositório** |
| Ligação ao Higgsfield, tabela de custos real, limites de gasto | ❓ a implementar / depende de ti |
| Linguagem de produção (a partir das referências) | ❓ referências em falta |

## 3. Conflitos encontrados
| # | Conflito | Proposta |
|---|---|---|
| C1 | Dôdo: código diz **ornitorrinco**; brief manda descrever "cartoon dodo" (ave) | Seguir o código; corrigir prompts |
| C2 | Landing antiga local (azul/amarelo, Nunito) vs app atual (escuro, dourado, Oswald/Manrope) | Seguir a app atual |
| C3 | Brief não define fontes; app usa Oswald + Manrope | Adotar Oswald + Manrope |
| C4 | Brief cita Pro 5,99 € / Pro Max 6,99 € sem dizer que é promoção; cheio é 8,99 € / 9,99 € | Mostrar sempre como promoção de lançamento |
| C5 | Spec economia "1 JC = 1 €" vs pacotes no código (10 JC = 20 € … 100 JC = 70 €); alerta jurídico sobre expiração | Não anunciar compra de JC até decidires |
| C6 | Spec "sem teto" vs código com teto de segurança 50 JC | Dizer "pode passar dos 20 JC", nunca "sem limite" |
| C7 | Tour Pro Max apresenta a Copa do Dôdo como exclusiva do Max; código e outros textos: Pro **e** Pro Max | Conteúdo diz "Pro e Pro Max"; corrigir texto na app |
| C8 | Tour Pro Max apresenta a cor do judogi como exclusiva do Max; servidor permite Pro | Idem |
| C9 | Brief: 3 redes; plano de marketing: 5 redes (+X, WhatsApp) | Confirmar |
| C10 | Idioma: plano = inglês global; app = 5 línguas; conversa em português | Confirmar idioma por rede |
| C11 | Brief usa Nano Banana; agora Higgsfield | Higgsfield como plataforma única? Confirmar |
| C12 | `utm_medium`: brief `reel/short/bio/story` vs construtor `social/video/story/bio/…` | Escolher uma convenção |
| C13 | Tagline "o jogo **oficial** dos fãs de judô" vs regra de não sugerir parceria com a IJF | Validar com advogado/marca |
| C14 | "Copa do Dôdo" é nome que não se traduz, mas o inglês mostra "Dôdo Cup" | Decidir |
| C15 | Duas branches no GitHub (`main` atual, `master` antiga) e pasta local desatualizada | Trabalhar só sobre `main` |
| C16 | Guia "Como se joga" fala em liga "nacional"; código só tem ligas oficiais mundial e continental | Confirmar |

## 4. Em falta
1. **Referências de produção** (vídeos/imagens) citadas no pedido — não foram anexadas nem estão no Projeto ou na pasta.
2. **Ferramenta "ITI"** — não identificada em lado nenhum.
3. **"Documento mestre/fundador"** citado pelos planos (secções 5, 27, 32, 38) — não encontrado.
4. **Logótipo vetorial** e regras de uso; vistas de lado/costas do Dôdo; voz do Dôdo.
5. **Higgsfield:** plano da conta, créditos, tabela de custos por modelo, acesso (conector).
6. **Limites de gasto** por vídeo e por mês.
7. **Música/narração:** fonte licenciada e tipo de voz (humana, IA, idioma).
8. Data oficial de lançamento (fecha a janela da promoção de 90 dias).
9. Estado atual das redes (@handles, posts já publicados) e acesso ao PostHog.
10. Versão do CapCut (desktop/telemóvel).

## 5. Plano de implementação por etapas
| Etapa | Conteúdo | Depende de | Estado |
|---|---|---|---|
| 0 | Base de conhecimento, pacote do Dôdo, templates, esqueleto de agentes e trava | — | ✅ feito |
| 1 | Decisões: conflitos C1–C16 e itens em falta 1–2, 5–7 | Kainan | aguarda |
| 2 | Instalar `conteudo/` + `.claude/` no repositório (branch nova, PR) | "sim" para escrever no repo | pronto |
| 3 | Script que extrai factos do código (pontos, preços, limites, calendário) para `conhecimento/factos.json`, para os agentes nunca ficarem desatualizados | etapa 2 | a implementar |
| 4 | Ligar Higgsfield ao Claude Code; testar só ferramentas de leitura; preencher tabela de custos; confirmar nomes das ferramentas na trava | acesso à conta | a implementar |
| 5 | **Piloto sem gasto até P2:** 1 pauta → roteiro completo → orçamento → tua aprovação | etapas 1 e 4 | — |
| 6 | Geração aprovada → pacote CapCut → montagem → publicação com UTM | P2 aprovado | — |
| 7 | Registo de resultados e primeira revisão dos agentes | 1–2 semanas de dados | — |
| 8 (opcional) | Ippon Studio para gravar cenas com o motor real (reduz gasto de geração) | decisão tua | especificado |

## 6. Primeira tarefa concreta
**Instalar o esqueleto no repositório da app (etapa 2)**: criar a branch `conteudo/maquina`, adicionar `conteudo/` (conhecimento, referência do Dôdo, templates, registo) e `.claude/agents/` + `.claude/settings.json` com a trava de gasto, e abrir um PR para reveres. Não mexe em nenhum ficheiro da app. Precisa só do teu "sim" (e de acesso de escrita ao GitHub a partir do teu computador ou desta sessão).
Em paralelo, a decisão que mais desbloqueia: **confirmar C1 (ornitorrinco) e enviar as referências de produção.**
