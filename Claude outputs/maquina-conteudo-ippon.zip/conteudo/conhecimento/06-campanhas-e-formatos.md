# 06 · Campanhas e formatos

## 1. Objetivo da fase 📄
Validar com gasto mínimo **se há apetite e se há pagantes**. Estrela-guia: **jogadores que voltam de uma competição para a seguinte**. Ordem de importância no lançamento: registo → ativação (montou equipa + capitão) → retenção.

## 2. Campanha âncora: Mundial de Baku 📄✅
- Início no calendário da app: **04/10/2026** (faltam 4 dias a 30/09).
- Ideia central (plano de marketing): "o jogo dos fãs de judô estreia-se no Mundial".
- Ciclo diário previsto: manhã "mercado fecha em X h" · durante as lutas reações com gráficos · noite recap (maior pontuador, maior valorização, melhor capitão).
- ❓ Estado real: perfis nas redes criados? posts semeados? registo EUIPO submetido? O plano de 10/09 pedia tudo isto antes de 04/10.

Depois: Abu Dhabi GS (29/10), Tokyo GS (05/12), Masters (18/12) e rodadas clássicas — cada uma é uma mini-campanha.

## 3. Ângulos para testar (brief) 📄
| Ângulo | `utm_content` |
|---|---|
| "Monta a tua equipa em 30 s" (100 JC, 8 atletas, capitão) | `como-jogar` |
| Emoção do mercado / subir de faixa | `emocao` |
| "O jogo que faltava aos fãs de judô" (Dôdo, tatame) | `posicionamento` |
| Dispute com os amigos (ligas, mata-mata) | `amigos` |
Formatos citados no KPI doc: "how to play in 20 s", "belt reveal", "biggest scorer of the round", "build a 100-coin team", "this shido just scored me points".

## 4. Redes e formatos ⚠️ (C9, C10)
| Rede | Formato citado | KPI principal |
|---|---|---|
| TikTok | vídeo 9:16, 15–30 s | views + taxa de conclusão |
| Instagram Reels | vídeo 9:16 | views + saves + partilhas |
| Instagram feed | carrossel | saves |
| YouTube Shorts | vídeo 9:16 | views + subscritores |
| X | tempo real, texto + gráfico | cliques no link |
| WhatsApp | retenção (grupo Pro Max) | — |
O brief limita a 3 redes (TikTok, Instagram, YouTube); o plano de marketing inclui X e WhatsApp. **Confirmar lista final e idioma por rede** (plano: inglês global; app: 5 línguas; conversa: português).

## 5. Links (UTM) ⚠️ (C12)
- Base: `https://www.ipponleague.com/` · minúsculas, sem acentos, hífens · **um link por variante**.
- `utm_source` = rede · `utm_campaign` = tema/rodada · `utm_content` = variante · `utm_term` = gancho (opcional).
- Conflito em `utm_medium`: o brief usa `reel/short/bio/story`; o construtor Ippon Links oferece `social, video, story, bio, post, ads, dm, referral, email, push, organico`. Escolher uma convenção.
