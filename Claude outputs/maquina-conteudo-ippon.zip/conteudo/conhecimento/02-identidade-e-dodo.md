# 02 · Identidade visual e Dôdo

Fonte: código da app (`components/Mascot.tsx`, `public/dodo.png`, `lib/faixas.ts`, `lib/tatames.ts`, `app/layout.tsx`, páginas `/inicio` e `/dodo`) + brief de marketing.

## 1. O Dôdo ✅
- **Espécie: ornitorrinco judoca** (comentário oficial em `Mascot.tsx`: "Mascote ornitorrinco judoca da Ippon League — o 'Dôdo'").
  ⚠️ **C1:** o brief antigo manda descrever "a cartoon dodo" (a ave) nos prompts. Está errado face ao desenho: bico de pato largo e laranja, cauda de castor verde-azulada. **Nos prompts, dizer "cartoon platypus judoka mascot" e SEMPRE anexar a referência.**
- Função narrativa ✅: é o **sensei** do jogador ("Sou o teu sensei aqui na Ippon League e vou guiar-te"). Fala na 1.ª pessoa, trata por "tu", tom caloroso e simples.
- Anatomia (do SVG, não alterar):
  - cabeça oval verde-azulada `#4DB6AC` (contorno `#2f8a80`); cauda `#39998f`
  - bico laranja `#FF8F00` com contorno `#E65100`, duas narinas; sorriso `#C2410C` nas faces felizes
  - olhos brancos com íris azul-escura `#1A237E` e brilho branco; sobrancelhas laranja `#E65100`
  - bochechas laranja translúcidas (faces felizes)
  - mãos redondas laranja `#E65100`; patas laranja `#FF8F00`
  - judogi **branco** `#f6f3ea` (borda `#d8d1c0`) ou **azul** `#2f6fb3` (borda `#1f4e80`) — personalização paga
  - faixa com nó e duas pontas; **cor = faixa do jogador** (ver tabela abaixo)
- Expressões oficiais (5): `feliz`, `determinado` (sobrancelhas franzidas, sem sorriso), `comemorando` (dois braços no ar), `indicando` (braço direito no ar, a apontar), `sabio` (óculos redondos — usado para dicas).
- Estilo: vetorial plano, formas arredondadas, contornos finos, sem texturas realistas.

### Pacote de referência gerado (sem custo)
`conteudo/dodo/referencia/` — 70 PNG 1024×1024 com fundo transparente + SVG, renderizados diretamente do componente oficial: 5 expressões × 7 faixas × 2 judogis. `sheet.png` = folha-resumo.
Usar estas imagens como **referência obrigatória** em qualquer geração com o Dôdo.

### O que falta para consistência em vídeo ❓
- Vistas de perfil, costas e ¾ (o SVG só tem frente).
- Regras de movimento (como anda, como faz um golpe, como reage) — não existem.
- Voz do Dôdo (se falar em narração) — não definida.
- Decisão: animar o Dôdo 2D a partir do SVG (custo zero de geração) vs. gerar versões 3D/cinemáticas no Higgsfield (custo e risco de deformação). **Precisa de decisão tua.**

## 2. Paleta da app ✅ (extraída das páginas atuais)
| Papel | Hex |
|---|---|
| Fundo principal | `#0c0e0d` |
| Superfícies / cartões | `#121815`, `#141a17`, `#1b211e` |
| Bordas | `#243029` |
| Verde tatame (superfície de destaque) | `#1c3a2e` |
| Texto principal (creme) | `#f1ede2` |
| Texto secundário | `#93a39a`, `#7c8a82` |
| Dourado (Pro) | `#d9a441` |
| Azul (Pro Max) | `#7fb8f5` |
| Verde positivo / valorização | `#7fd1a3`, `#aee9c9` |
| Vermelho negativo | `#e2655a` |

⚠️ **C2:** a pasta local tem uma landing antiga com azul `#1565C0` e amarelo `#FDD835` e fonte Nunito — **obsoleta, não usar**.

### Cores das faixas ✅ (`lib/faixas.ts`)
branca `#efeadd` · azul `#3b6fb5` · amarela `#e8c84b` · verde `#3f8f5a` · roxa `#7a4fa3` · marrom `#6b4a2f` · preta `#1a1a1a`

### Temas de tatame ✅ (`lib/tatames.ts`) — dentro / fora
Amarelo/Azul (padrão) `#e6b422` / `#2f6fb3` · Amarelo/Vermelho `#e6b422` / `#b33f3f` · Azul/Vermelho `#2f6fb3` / `#b33f3f` · Amarelo/Verde `#e6b422` / `#3f9962` · Verde/Vermelho `#3f9962` / `#b33f3f`
❓ O brief fala em "verde do tatame" — confirmar se é o verde de superfície `#1c3a2e` ou um tema de tatame.

## 3. Tipografia ✅ (`app/layout.tsx`)
- **Oswald** — títulos, números, rótulos em MAIÚSCULAS com espaçamento (na app aparece como variável `--font-geist-mono`, nome enganador).
- **Manrope** — texto corrido (variável `--font-geist-sans`).
- Ambas Google Fonts (licença livre para uso comercial — ❓ confirmar se queres fonte própria para vídeo).

## 4. Elementos visuais da marca
- ✅ Tatame (grelha do "Meu Time"), avatares de kimono de costas com back number e sigla do país, escudo da equipa (`Escudo.tsx`), troféu da Copa do Dôdo (`TrofeuDodo.tsx`), cards de desempenho/certificado.
- ❓ Logótipo: no repositório só existem `icon-192.png`, `icon-512.png`, `apple-touch-icon.png`. **Falta ficheiro de logótipo vetorial** (e regras de uso).

## 5. Proibido ✅/📄
Fotos ou vídeos de atletas reais · imagens de transmissões IJF/JudoBase · logos IJF/federações/JudoBase · alterar anatomia/cores do Dôdo · pôr o Dôdo com faixa de cor que não existe · rostos humanos fotorrealistas que pareçam atletas reais.
