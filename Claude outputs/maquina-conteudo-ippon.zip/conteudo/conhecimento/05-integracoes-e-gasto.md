# 05 · Integrações e controlo de gasto

## 1. Estado das integrações
| Ferramenta | Estado | Notas |
|---|---|---|
| **Higgsfield** | ❓ não ligado a esta sessão; plano/créditos da conta desconhecidos | Ver secção 2 |
| **CapCut** | ❓ sem integração verificada | Entrega = pasta organizada para importar à mão (secção 3) |
| **"ITI"** | ❓ **não identificada** | Não aparece em nenhum documento nem no código. Precisa que digas o nome completo/site. |
| Nano Banana (Gemini) | 📄 citado no brief antigo para imagens | ❓ substituído pelo Higgsfield? |
| PostHog | ✅ existe no código (eventos de funil) | Leitura de resultados — acesso ❓ |
| Ippon Links (`/admin/utm`) | ✅ existe | Construtor de UTMs só para admin |

## 2. Higgsfield — o que se sabe (fontes externas, ❓ confirmar na tua conta)
- Há um conector MCP oficial em `https://mcp.higgsfield.ai`; liga-se como "custom connector" e faz login na conta; **cada geração desconta créditos da conta às tarifas normais**; existe a opção "Always Allow" que dispensa confirmação por geração. ([miracamp](https://www.miracamp.com/learn/content-creation/claude-x-higgsfield-mcp-connector))
- Planos e custos por modelo publicados por terceiros em ago/2026 (Starter ~270 créditos, Plus 1.200, Ultra 3.000; ex.: Seedance 2.0 720p 5 s ≈ 22–23 créditos; Kling 3.0 720p 5 s ≈ 7–10; Nano Banana Pro imagem ≈ 2). ([creatify](https://creatify.ai/blog/higgsfield-pricing-(2026)-plans-and-what-you-ll-actually-pay))
- **Estes números NÃO entram em orçamentos** até serem confirmados no ecrã de preços da tua conta. O orçamentista usa só a tabela da secção 4, preenchida por ti.

## 3. Entrega para CapCut (sem integração direta)
```
entrega-capcut/<data>_<slug>/
  00_LEIA-ME.md          ordem das cenas, tempos, transições, textos, música
  01_video/              cena01.mp4, cena02.mp4 … (nome = ordem)
  02_dodo/               PNG/SVG do Dôdo usados
  03_graficos/           cards, textos em PNG transparente
  04_audio/              música (com licença anotada), narração, efeitos
  05_legendas/           legendas por língua (.srt) — ❓ confirmar importação na tua versão do CapCut
  06_capa/               thumbnail/capa por rede
```

## 4. Tabela de custos confirmada ❓ (preencher por ti, a partir da conta)
| Modelo | Tipo | Resolução | Duração | Créditos | Data de confirmação |
|---|---|---|---|---|---|
| | | | | | |
Plano da conta: ___ · Créditos disponíveis: ___ · Custo real por crédito (€): ___

## 5. Controlo de gasto — 4 travas
1. **Aprovação escrita (P2):** `campanhas/<slug>/aprovacao.json` com lista exata de chamadas aprovadas, créditos máximos, validade e o hash SHA-256 do `roteiro.md` aprovado.
2. **Trava técnica (hook do Claude Code):** `scripts/guarda-gasto.mjs` corre antes de qualquer ferramenta cujo nome contenha "higgsfield". Bloqueia se: não houver campanha ativa; aprovação inexistente, expirada ou não "aprovado"; roteiro alterado depois da aprovação; chamadas ou créditos aprovados esgotados. Ferramentas só de leitura (listar modelos, saldo, histórico) passam. Tudo fica em `gastos.jsonl`.
3. **Confirmação manual:** `permissions.ask` para ferramentas Higgsfield no Claude Code — cada chamada pede o teu clique.
4. **No Higgsfield:** manter "Always Allow" **desligado**; ❓ se a conta permitir, definir limite mensal de créditos.

## 6. Limites de orçamento ❓
Por vídeo: ___ créditos · Por mês: ___ créditos / ___ € · Margem de retakes por defeito: ___ %. **Tu decides; nenhum valor foi assumido.**
