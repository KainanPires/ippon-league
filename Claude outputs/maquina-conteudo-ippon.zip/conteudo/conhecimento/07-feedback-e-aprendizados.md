# 07 · Feedback e aprendizados

## 1. Registo por peça (`aprendizados/registro.csv`)
Colunas: `data_publicacao, slug, rede, formato, angulo, utm_campaign, utm_content, duracao_s, idioma, creditos_gastos, custo_eur, views, conclusao_pct, saves, partilhas, cliques, registos, equipas_montadas, pro_iniciados, notas`.
Fontes: analytics nativas de cada rede + PostHog por `utm_content` (eventos ✅ no código: `landing_viewed`, `signup_started`, `signup_completed`, `team_saved`, `trial_started`, `subscription_started`).

## 2. Ritual (📄 KPI doc)
Segunda-feira, 20 min: formato/mensagem vencedora · contas novas · quantos voltaram · maior estrangulamento → **uma** decisão para a semana.
Métricas de vencedor: vídeo = conclusão + partilhas; carrossel = saves; X = cliques; mensagem = registos ÷ cliques.

## 3. Biblioteca de aprovados
`aprendizados/aprovados/<slug>/` — roteiro final, prompts que resultaram, cenas descartadas (e porquê), resultado. Os agentes consultam antes de criar.

## 4. Regras aprendidas
Cada correção do Kainan entra aqui, datada, com a regra resultante.
- 2026-09-30 · O Dôdo é um **ornitorrinco**, não um dodô — nunca descrevê-lo como ave nos prompts.
