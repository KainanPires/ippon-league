# 01 · Conhecimento verificado do produto

> **Regra dos agentes:** só afirmam em conteúdo o que está nesta página com estado ✅.
> Tudo o que for ⚠️ ou ❓ exige confirmação do Kainan antes de ir para roteiro.
> Quando o código mudar, esta página é revista (ver `scripts/` no plano — etapa 3).

**Fonte principal:** repositório `github.com/KainanPires/ippon-league`, branch `main`, commit `e816cac` (29/09/2026).
**Fontes secundárias:** documentos em `ippon-league/Claude outputs/` (brief, plano de marketing, KPIs, spec economia v2, plano Ippon Studio).
**Atenção:** a pasta local `C:\Users\kaina\ippon-league` está desatualizada (esqueleto de junho, branch `master`). Não usar como referência de produto.

Legenda: ✅ verificado no código · 📄 só em documento · ⚠️ conflito · ❓ por confirmar

---

## 1. O que é
- ✅ Web app/PWA "Ippon League", tagline no código: **"O jogo oficial dos fãs de judô."** (ver ⚠️ C13 sobre a palavra "oficial").
- ✅ Stack: Next.js · Supabase · Stripe · PostHog · cron. Domínio usado no código: `https://www.ipponleague.com`.
- ✅ 5 línguas: PT (origem), EN, ES, FR, DE. Termos de judô não se traduzem (ippon, waza-ari, yuko, shido, hansoku-make, judogi, tatame, dojo, golden score, osaekomi, nomes das faixas). Nomes de produto não se traduzem: Ippon League, Ippon Pro, Pro Max, Judocoins (JC), Copa do Dôdo.

## 2. Como se joga (fonte: `lib/engine.ts`, `lib/i18n.ts` → secção "cj." Como se joga)
- ✅ Começa com **100 Judocoins (JC)**.
- ✅ Equipa de **8 atletas: 4 masculinos + 4 femininos**, e **1 capitão**.
- ✅ **Capitão pontua a dobrar** (tudo ×2; "um ippon do capitão vale +20").
- ✅ Pontua pelas **ações reais nas lutas**, não por medalhas.

### Tabela de pontuação ✅ (`POINTS` + funções de shido)
| Ação | Aplica | Sofre |
|---|---|---|
| Ippon | +10 | −5 |
| Waza-ari | +4 | −2 |
| Yuko | +2 | −1 |
| Hansoku-make direto | — | −10 |
| Shido (crescente) | provocado: +1, +2, +3 (total +6 ao 3.º) | recebido: −2, −3, −4 (total −9 ao 3.º) |

- ✅ Ações acumulam (yuko + waza-ari + ippon = 16).

## 3. Rodadas e calendário ✅ (`lib/calendario.ts`, `lib/classicos.ts`)
- Cada competição (Grand Slam, Grand Prix, Mundial, Continental/Open, Masters) é uma **rodada**. O mercado fecha antes da competição.
- **Rodadas clássicas:** semanas sem competição real são preenchidas com competições antigas do JudoBase (2015–2025), marcadas "Clássico".
- Próximas rodadas no calendário do código:
  - Mundial de Baku (Individuais) — início 04/10/2026
  - GP Marrakech 2019 (Clássico) — 17/10 · GP Zagreb 2021 (Clássico) — 22/10
  - Abu Dhabi Grand Slam — 29/10 · Montreal Panamerican Open — 07/11 · Zagreb Grand Prix — 13/11
  - Kowloon Asian Open — 21/11 · Rome European Open — 28/11 · Tokyo Grand Slam — 05/12
  - Dar Es Salaam African Open — 13/12 · Dushanbe World Judo Masters — 18/12 · GS Tel Aviv 2022 (Clássico) — 26/12
- 📄 O plano de marketing indica Mundial de 4 a 11/10; o código só guarda a data de início.

## 4. Mercado e património ✅ (`computeNewPrice`, spec economia v2)
- Preço de estreia do atleta: expectativa **70% média 12 meses + 30% últimas 3 competições**, escala **2–20 JC**.
- Durante a época: **D = pontos − preço**; **novo preço = preço + 50% de D**. Piso 2 JC.
- ⚠️ Teto: a spec diz "sem teto"; o código tem **rede de segurança de 50 JC** (`TETO_PRECO`). Em conteúdo: "pode passar dos 20 JC" ✅; **não** dizer "sem limite".
- 📄 Património do jogador é assimétrico (ganha 25% de D na subida, perde 50% de |D| na descida) — implementado em `lib/congelar.ts` segundo o comentário do motor. ❓ Confirmar antes de explicar em vídeo (é regra sensível).
- ✅ Época = ano civil; reset a 30 de dezembro (re-preço 70/30, orçamento volta a 100 JC).

## 5. Faixas ✅ (`lib/faixas.ts`, `lib/engine.ts`)
- 7 faixas, da mais baixa à mais alta: **branca → azul → amarela → verde → roxa → marrom → preta**.
- Calculadas por **percentil mensal** entre jogadores ativos: preta top 5% · marrom até 15% · roxa até 30% · verde até 50% · amarela até 70% · azul até 90% · branca o resto.
- Sobe e desce mês a mês. A faixa muda o visual do jogo e a faixa do Dôdo.

## 6. Ligas e competições entre jogadores ✅
- Ligas **oficiais (mundial + continental)** e **de amigos**; formato pontos e formato copa (mata-mata). ⚠️ O guia "Como se joga" fala em liga "nacional", mas o código de ligas oficiais só tem `mundial` e `continental` (C16).
- Limites de ligas de amigos por plano (`lib/planos.ts`): Grátis 1 + 1 copa · Pro 5 + 5 · Pro Max 10 + 10.
- Pro/Pro Max entram automaticamente na **Liga Mundial** e na liga do seu continente.
- **Copa do Dôdo** (`lib/sorteioDodo.ts`): mata-mata mundial entre continentes, **32 lugares**, **6 por continente** (EUR, PAN, ASI, AFR, OCE = 30) + vagas restantes sorteadas entre todos; entrada **por sorteio**; só **Pro ou Pro Max** se inscrevem. Ser Pro dá direito a inscrição, não garante vaga.
- ✅ Cards/certificados partilháveis existem (`CartaoDesempenho`, `CartaoCertificado`, `CartaoEquipa`).

## 7. Planos e preços ✅ (`lib/precos.ts`, `lib/planos.ts`)
| | Promoção de lançamento | Preço cheio |
|---|---|---|
| Ippon Pro | 5,99 €/mês | 8,99 €/mês |
| Ippon Pro Max | 6,99 €/mês | 9,99 €/mês |
- Mensal, renova sozinho, cancela quando quiser (mantém até ao fim do mês pago). 7 dias de teste.
- Promoção: **janela de 90 dias após o lançamento**, **6 meses de desconto por pessoa**. ❓ Data oficial de lançamento (define quando a janela fecha) não está no código.
- Subida Pro → Pro Max depois do teste: taxa única 0,99 €.
- Cobrança em euros, convertida para a moeda local no checkout.
- **Pro:** scout avançado (histórico de atletas), análise do time e dica de capitão, chave congelada das competições, ligas oficiais, até 5 ligas, Copa do Dôdo, cor do judogi do Dôdo (⚠️ C8).
- **Pro Max:** tudo do Pro + chave **ao vivo**, aviso quando o atleta favorito vai lutar, grupo de WhatsApp (entrada aprovada por admin), até 10 ligas, **cor do tatame** (5 temas, só Pro Max).
- Mensagem oficial: "O Pro não joga por ti." / "Joga com mais informação e compete pelo topo do ranking" (fase de testes: **sem prémios**).

## 8. Judocoins pagos ⚠️ (não usar em conteúdo até resolver)
- Código tem pacotes de 10 JC/20 € até 100 JC/70 €, que expiram a 30/12 e nunca permitem trocar com o mercado fechado.
- A spec economia v2 diz "1 JC = 1 €" (C5) e há alerta jurídico pendente sobre a expiração.

## 9. Regras de conteúdo que vêm do produto ✅/📄
- Nunca fotos/vídeos reais de atletas nem imagens das transmissões IJF/JudoBase (direitos).
- Nunca logótipos de IJF/federações/JudoBase como se fossem parceiros.
- Não revelar escalações de rivais.
- Identidade = Dôdo + avatares de kimono de costas com back number e sigla do país + cards da app.

## 10. Funcionalidades em plano, NÃO existentes (não anunciar)
- 📄 **Ippon Studio** (`/admin/studio`, simulador para gravar cenas com o motor real): planeado, **não implementado**.
- 📄 Blog/notícias existe no código (`/blog`, "Blog do Dôdo"); área de redator por formalizar.
