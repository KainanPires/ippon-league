# 03 · Diretrizes de produção

## 1. Princípios (definidos pelo Kainan)
1. As referências definem uma **linguagem de produção**, não um roteiro a repetir. Cada tema tem narrativa própria.
2. Preservar identidade visual, Dôdo, cores, fontes e qualidade (ver 02).
3. **Nenhuma geração paga sem roteiro completo + orçamento aprovados por escrito.** Aprovar a ideia não autoriza gastar.
4. Não inventar regras, valores, funcionalidades ou acessos — só factos ✅ da página 01.

## 2. Linguagem de produção ❓ (pendente)
As referências de vídeo mencionadas **não foram encontradas** (nem anexadas à conversa, nem no Projeto, nem na pasta local). Esta secção fica por preencher quando chegarem, com: ritmo de cortes, tipo de gancho, estilo de câmara, tratamento de texto, uso de som, paleta de transições.

Enquanto isso, valem as regras já decididas nos documentos:
- 📄 Vertical 9:16; Shorts/Reels/TikTok de **15–30 s**.
- 📄 Gancho nos **primeiros 2 s**; texto grande legível **sem som**; **1 CTA** claro ("Joga grátis em ipponleague.com"); Dôdo presente.
- 📄 Sem cara (conteúdo "faceless"): Dôdo, avatares, cards, gravações de ecrã da app.

## 3. Fluxo com portões de aprovação
| Portão | O que se aprova | Autoriza |
|---|---|---|
| **P1 · Pauta** | ideia, objetivo, público, ângulo, formato, rede, CTA | escrever roteiro (custo zero) |
| **P2 · Roteiro + Orçamento** | roteiro completo (template) + orçamento por cena | **gastar até ao limite aprovado**, só nas chamadas listadas |
| **P3 · Cenas geradas** | revisão das cenas antes da montagem | regenerar só o que estiver no orçamento de retakes aprovado |
| **P4 · Montagem** | corte final vindo do CapCut | publicar |
| **P5 · Resultados** | números registados | virar aprendizado (07) |

Qualquer mudança no roteiro depois de P2 **invalida a aprovação** (a trava técnica compara o hash do ficheiro).

## 4. O que um roteiro tem de ter (template em `templates/roteiro.md`)
Por vídeo: título, objetivo, público, rede(s), formato, duração total, idioma, CTA, link UTM, música (fonte e licença), voz/narração, factos usados (com referência à página 01).
Por cena: nº, tempo (in–out e duração), cenário, personagens, ação, enquadramento, movimento de câmara, texto em ecrã, narração/fala, som/efeitos, transição de saída, **origem** (gravação de ecrã · SVG animado · geração Higgsfield · asset existente) e, se for gerada, modelo + prompt + referência + créditos estimados.

## 5. Origem das cenas — ordem de preferência (para gastar menos)
1. Gravação de ecrã da app real (custo zero).
2. Dôdo SVG oficial animado no CapCut (custo zero).
3. Assets existentes (cards, escudo, troféu).
4. Geração paga no Higgsfield — só quando acrescenta algo que 1–3 não conseguem.

## 6. Carrosséis
📄 Formato citado para Instagram ("how it works", cards de conquista); KPI = saves. ❓ Dimensão e número de slides a confirmar (ver 06).

## 7. Qualidade mínima antes de P4
- Factos batem com a página 01 (verificador).
- Dôdo fiel à referência (sem deformações, bico/cores corretos).
- Nada de atletas reais, logos IJF, música sem licença.
- Texto legível a 1 m de distância no telemóvel; zonas seguras das redes respeitadas.
- Preços: se aparecerem, **indicar que é promoção de lançamento** e o preço cheio quando aplicável.
