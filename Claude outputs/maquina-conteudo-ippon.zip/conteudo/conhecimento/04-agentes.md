# 04 · Agentes e responsabilidades

Implementação: **subagentes do Claude Code** em `.claude/agents/` dentro do repositório da app, para poderem ler o código (fonte da verdade do produto). Esqueleto já preparado — ver plano, etapa 3.

| Agente | Faz | Nunca faz | Entrega |
|---|---|---|---|
| **verificador-produto** | Responde a dúvidas sobre o jogo com fonte (página 01 + código). Marca o que não está verificado. | Inventar regra, preço ou funcionalidade. | Factos com ✅/❓ e ficheiro de origem |
| **estrategista-pauta** | Transforma ideia, dúvida do público ou objetivo em pauta: objetivo, público, ângulo, formato, rede, CTA, `utm_content`. | Escrever roteiro antes de P1. | `pauta.md` |
| **roteirista** | Escreve o roteiro completo cena a cena no template, com narrativa própria para o tema. | Copiar a estrutura de uma referência. | `roteiro.md` |
| **diretor-de-arte** | Guardião do Dôdo e da identidade. Revê roteiro, define prompts e referências por cena. | Aprovar Dôdo fora do modelo. | notas + prompts no roteiro |
| **orcamentista** | Calcula créditos e custo por cena com a tabela de custos **confirmada** (05). Mostra margem de retakes separada. | Chamar o Higgsfield. | `orcamento.md` |
| **produtor-higgsfield** | Único agente autorizado a chamar o Higgsfield, e só com aprovação válida. Regista cada chamada. | Gerar fora da lista aprovada ou acima do limite. | ficheiros em `cenas/` + `gastos.jsonl` |
| **montador-capcut** | Organiza a entrega para montagem: pastas, nomes, ordem, legendas, textos, música, guia de montagem. | Publicar. | pasta `entrega-capcut/` |
| **adaptador-redes** | Adapta a peça aprovada a cada rede (duração, zonas seguras, legenda, hashtags, UTM próprio por variante). | Mudar factos ou mensagem aprovada. | `publicacao.md` por rede |
| **analista-aprendizados** | Regista resultados (views, conclusão, saves, cliques, registos por `utm_content`), atualiza exemplos aprovados e regras. | Tirar conclusões com amostra mínima sem o dizer. | linha em `aprendizados/registro.csv` + notas |

Papel do Kainan: aprova P1–P4, define limites de gasto, confirma factos ❓.

## Encadeamento
Ideia/dúvida/objetivo → estrategista (P1) → roteirista + verificador + diretor-de-arte → orcamentista → **P2 (Kainan)** → produtor-higgsfield → **P3** → montador-capcut → **P4** → adaptador-redes → publicar → analista (P5).

## Como melhoram
- Cada peça aprovada vai para `aprendizados/aprovados/` com roteiro, prompts e resultado — vira exemplo para o roteirista e o diretor.
- Cada correção tua ("isto não é o Dôdo", "este facto está errado") vira regra nesta pasta de conhecimento.
