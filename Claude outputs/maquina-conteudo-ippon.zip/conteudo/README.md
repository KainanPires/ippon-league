# conteudo/ · Máquina de Conteúdo da Ippon League

Vive dentro do repositório da app para os agentes lerem o código (fonte da verdade do produto). Não altera nenhum ficheiro da app.

```
conteudo/
  conhecimento/   00 (estado e plano) + 01–07 (produto, identidade, produção, agentes, integrações/gasto, campanhas, feedback)
  dodo/referencia 70 PNG + SVG do Dôdo oficial (5 expressões × 7 faixas × 2 judogis) + sheet.png
  templates/      roteiro.md · orcamento.md · aprovacao.exemplo.json
  campanhas/      uma pasta por peça: pauta, roteiro, orçamento, aprovação, gastos, cenas, entrega-capcut
  aprendizados/   registro.csv + aprovados/
  scripts/        guarda-gasto.mjs (trava) · aprovar.mjs (só tu corres)
.claude/
  agents/         9 subagentes (ver conhecimento/04-agentes.md)
  settings.json   trava de gasto (hook) + confirmação manual + proibições
```

## Fluxo
1. "Quero um vídeo sobre X" → `estrategista-pauta` → **P1**
2. `roteirista` + `verificador-produto` + `diretor-de-arte` → roteiro completo
3. `orcamentista` → orçamento → **P2: tu corres** `node conteudo/scripts/aprovar.mjs <slug> <créditos_máx> <dias>`
4. `produtor-higgsfield` gera só o aprovado → **P3**
5. `montador-capcut` → pasta para o CapCut → **P4** → `adaptador-redes` → publicar
6. `analista-aprendizados` → **P5**

## Trava de gasto (testada)
Bloqueia qualquer ferramenta Higgsfield que não seja de leitura quando: não há campanha ativa · sem aprovação · aprovação expirada · roteiro mudou depois de aprovado · chamadas ou créditos aprovados esgotados.
Conservadora de propósito: cada chamada conta como usada logo que é autorizada, mesmo que depois falhe ou a recuses no pedido de confirmação.
⚠️ Confirmar os nomes reais das ferramentas do Higgsfield depois de ligar o conector (etapa 4) e ajustar `permissions.ask` em `.claude/settings.json` ao nome do servidor.
