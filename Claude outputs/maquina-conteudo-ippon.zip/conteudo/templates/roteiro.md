# Roteiro · <título>

> Estado: RASCUNHO · Portão P2 por aprovar · **Nenhuma geração autorizada.**

## Ficha
| Campo | Valor |
|---|---|
| Slug | `aaaa-mm-dd_tema` |
| Objetivo (1 frase) | |
| Público | |
| Ângulo (06 §3) | |
| Rede(s) e formato | ex.: TikTok + Reels + Shorts · 9:16 |
| Duração total | __ s |
| Idioma(s) | |
| CTA | |
| Link UTM | `https://www.ipponleague.com/?utm_source=…&utm_medium=…&utm_campaign=…&utm_content=…` |
| Música | faixa · fonte · licença |
| Narração | sim/não · voz · idioma |
| Factos usados | lista, cada um com referência à página 01 (✅ obrigatório) |

## Sinopse (3–5 linhas)
Como o vídeo se sente do princípio ao fim.

## Cenas
### Cena 01 · 00:00–00:02 (2 s) · GANCHO
- **Origem:** gravação de ecrã / Dôdo SVG animado / asset existente / Higgsfield
- **Cenário:**
- **Personagens:** (Dôdo — expressão, faixa, judogi)
- **Ação:**
- **Enquadramento:** (plano geral / médio / close / detalhe)
- **Câmara:** (fixa / push-in / pan / orbital…)
- **Texto em ecrã:** (texto exato + posição + fonte)
- **Narração / fala:**
- **Som / efeitos:**
- **Transição de saída:**
- **Se Higgsfield:** modelo · resolução · duração · referência(s) · prompt · créditos estimados

(repetir por cena)

## Riscos e alternativas
- O que pode sair mal na geração e o plano B de custo zero.
