# Orçamento · <slug>

> Custos só com base na tabela confirmada (05 §4). Data da tabela: ____

| Chamada | Cena | Modelo | Resolução | Duração | Créditos/unid. | Qtd | Créditos |
|---|---|---|---|---|---|---|---|
| g01 | 01 | | | | | 1 | |
| **Subtotal base** | | | | | | | **__** |
| Margem de retakes (definida por ti) | | | | | | | __ |
| **Máximo a autorizar** | | | | | | | **__ créditos ≈ __ €** |

Custo zero (sem geração): cenas __, __ (gravação de ecrã / SVG / assets).
Créditos disponíveis na conta antes: __ · depois (máx.): __
Limite por vídeo (05 §6): __ → dentro / fora do limite.
