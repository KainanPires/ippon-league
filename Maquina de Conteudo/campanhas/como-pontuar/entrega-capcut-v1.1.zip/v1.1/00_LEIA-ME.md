# Montagem no CapCut · How scoring works — não é a medalha, é a luta (v1.1)

Duração total: 89 s · Formato: 9:16, 1080×1920, 30 fps

Este pacote é para montagem MANUAL. Não é um projeto nativo do CapCut.

## Passos

1. Criar um projeto novo no CapCut com a proporção indicada acima.
2. Importar a pasta `cenas/` e colocar os ficheiros na linha do tempo pela ordem do número (01, 02, …).
3. Ajustar a duração de cada cena à tabela abaixo.
4. Adicionar os textos de `textos-ecra.csv` (fonte Oswald para títulos, Manrope para texto; creme #f1ede2 e dourado #d9a441).
5. Narração: gravar ou importar o áudio a partir de `narracao/`; o texto corrido está em `narracao-corrida.txt`.
6. Legendas: `legendas-narracao.srt` é um SRT padrão. Se a tua versão do CapCut importar legendas, usa-o; se não, copia o texto à mão.
7. Música e efeitos: seguir `mapa-musical.csv` e `efeitos-transicoes.csv`. Usar só música com licença confirmada.
8. Exportar e enviar o vídeo final para revisão (portão P4).

## Linha do tempo

| # | Cena | Início | Fim | Ficheiro | Transição de saída |
|---|---|---|---|---|---|
| 01 | c01 | 00:0000 | 00:0009 | 01_c01_PENDENTE.txt | corte seco |
| 02 | c02 | 00:0009 | 00:0025 | 02_c02_PENDENTE.txt | zoom no 48 |
| 03 | c03 | 00:0025 | 00:0031 | 03_c03_PENDENTE.txt | corte |
| 04 | c04 | 00:0031 | 00:0036 | 04_c04_PENDENTE.txt | corte |
| 05 | c05 | 00:0036 | 00:0041 | 05_c05_PENDENTE.txt | corte |
| 06 | c06 | 00:0041 | 00:0049 | 06_c06_PENDENTE.txt | corte |
| 07 | c07 | 00:0049 | 01:0004 | 07_c07_PENDENTE.txt | corte |
| 08 | c08 | 01:0004 | 01:0009 | 08_c08_PENDENTE.txt | corte |
| 09 | c09 | 01:0009 | 01:0017 | 09_c09_PENDENTE.txt | corte |
| 10 | c10 | 01:0017 | 01:0029 | 10_c10_PENDENTE.txt | fim (loop para a medalha) |

## Em falta

- 01 c01 (higgsfield (G1) + texto no CapCut)
- 02 c02 (motion (estúdio de cenas))
- 03 c03 (motion (estúdio de cenas))
- 04 c04 (motion (estúdio de cenas))
- 05 c05 (motion (estúdio de cenas))
- 06 c06 (motion (estúdio de cenas))
- 07 c07 (motion (estúdio de cenas))
- 08 c08 (motion (estúdio de cenas))
- 09 c09 (motion (estúdio de cenas) + Dôdo 2D)
- 10 c10 (higgsfield (G2) + ecrã final)
